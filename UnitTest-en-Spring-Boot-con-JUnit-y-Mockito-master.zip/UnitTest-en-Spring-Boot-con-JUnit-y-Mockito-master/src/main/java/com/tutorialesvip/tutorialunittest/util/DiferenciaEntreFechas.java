package com.tutorialesvip.tutorialunittest.util;

import org.springframework.stereotype.Component;

import com.tutorialesvip.tutorialunittest.businessException.ApplicationException;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

@Component
public class DiferenciaEntreFechas {

	public Period calculateYearsOfIndependency(String independenceDay, LocalDate today) throws ApplicationException {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
		LocalDate localDate = null;
		if (independenceDay == null || independenceDay.isEmpty()) 
			throw new ApplicationException();
		if (today == null) 
			throw new ApplicationException();
		localDate = LocalDate.parse(independenceDay, formatter);
		if (localDate.compareTo(today) > 0) {
			throw new ApplicationException();
		}
		return Period.between(localDate, today);
	}
}