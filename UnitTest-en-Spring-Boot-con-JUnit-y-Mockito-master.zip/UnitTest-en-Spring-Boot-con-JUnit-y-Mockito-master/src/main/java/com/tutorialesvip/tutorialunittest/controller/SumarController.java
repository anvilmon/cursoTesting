package com.tutorialesvip.tutorialunittest.controller;

import java.text.DecimalFormat;

import org.springframework.web.bind.annotation.RestController;

import com.tutorialesvip.tutorialunittest.models.SumarResult;

@RestController
public class SumarController {

	DecimalFormat df = new DecimalFormat("#.##");

	/**
	 * Formatea a 2 decimales y redondea, no trunca
	 */
	public SumarResult sumar(Object d, Object e) {

		SumarResult result;

		if (d == null ) d= Double.valueOf (0.0);
		if (e == null ) e= Double.valueOf (0.0);

		if ((d instanceof Number) && (e instanceof Number)) {

			String operando1 = df.format(d).replace(",", ".");
			String operando2 = df.format(e).replace(",", ".");

			Double op1 = Double.valueOf(operando1);
			Double op2 = Double.valueOf(operando2);

			String resultText = df.format(op1+op2).replace(",", ".");	

			result = new SumarResult(null, Double.valueOf(resultText));

		}else {
			try {
				Double op1 = null;
				Double op2 = null;
				
				if(d instanceof Number) {
					String operando1 = df.format(d).replace(",", "."); 
					op1 = Double.valueOf(operando1);
				}else {
					op1 = castAsNumber(d);
				}
				if(e instanceof Number) {
					String operando2 = df.format(e).replace(",", "."); 
					op2 = Double.valueOf(operando2);
				}else {
					op2 = castAsNumber(e);
				}		
						
						
				String resultText = df.format(op1+op2).replace(",", ".");	
				result = new SumarResult(null, Double.valueOf(resultText));
			}catch(Exception ex) {
				result = new SumarResult("ERROR", null);
			}
		}

		return result;
	}

	private Double castAsNumber (Object o) {
		if ((o instanceof String)) {
			Double result = Double.valueOf(o.toString());
			return result;
		}else {
			throw new NumberFormatException();
		}

	}

}

