package com.tutorialesvip.tutorialunittest.controller;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.tutorialesvip.tutorialunittest.businessException.ApplicationException;
import com.tutorialesvip.tutorialunittest.models.Country;
import com.tutorialesvip.tutorialunittest.models.CountryResponse;
import com.tutorialesvip.tutorialunittest.repositories.CountryRepository;
import com.tutorialesvip.tutorialunittest.util.DiferenciaEntreFechas;

/**
 * Author: VIP
 */
@RestController()
public class IndependencyController {

    
    
    CountryRepository countryRepository;
    DiferenciaEntreFechas diferenciaEntreFechas;

    public IndependencyController(CountryRepository countryRepository,DiferenciaEntreFechas diferenciaEntreFechas) {
        this.countryRepository = countryRepository;
        this.diferenciaEntreFechas = diferenciaEntreFechas;
    }

    @GetMapping(path = "/country/{countryId}")
    public ResponseEntity<CountryResponse> getCountryDetails(@PathVariable("countryId") String countryId) throws ApplicationException {
    	Optional<Country> country;
    	CountryResponse countryResponse;
        country = Optional.of(new Country());
        countryResponse = new CountryResponse();

        country = Optional.ofNullable(countryRepository.findCountryByIsoCode(countryId.toUpperCase()));

        if (country.isPresent()) {
            Period period = diferenciaEntreFechas.calculateYearsOfIndependency(country.get().getCountryIdependenceDate(), LocalDate.now());
            countryResponse.setCountryName(country.get().getCountryName());
            countryResponse.setCapitalName(country.get().getCountryCapital());
            countryResponse.setIndependenceDate(country.get().getCountryIdependenceDate());
            countryResponse.setDayssOfIndependency(period.getDays());
            countryResponse.setMonthsOfIndependency(period.getMonths());
            countryResponse.setYearsOfIndependency(period.getYears());
        }
        return ResponseEntity.ok(countryResponse);
    }
    
    @GetMapping(path = "/country/all")
    public ResponseEntity<List<CountryResponse>> getAllCountries() throws ApplicationException {
    	List<Country> countries = countryRepository.findAll();
        CountryResponse countryResponse;
        List<CountryResponse> lCountryResponse = new ArrayList<>();

        if (countries != null && !countries.isEmpty()) {
        	for (Country country: countries) {
        		countryResponse = new CountryResponse();
	            Period period = diferenciaEntreFechas.calculateYearsOfIndependency(country.getCountryIdependenceDate(), LocalDate.now());
	            countryResponse.setCountryName(country.getCountryName());
	            countryResponse.setCapitalName(country.getCountryCapital());
	            countryResponse.setIndependenceDate(country.getCountryIdependenceDate());
	            countryResponse.setDayssOfIndependency(period.getDays());
	            countryResponse.setMonthsOfIndependency(period.getMonths());
	            countryResponse.setYearsOfIndependency(period.getYears());
	            lCountryResponse.add(countryResponse);
        	}
        }
        return ResponseEntity.ok(lCountryResponse);
    }
}