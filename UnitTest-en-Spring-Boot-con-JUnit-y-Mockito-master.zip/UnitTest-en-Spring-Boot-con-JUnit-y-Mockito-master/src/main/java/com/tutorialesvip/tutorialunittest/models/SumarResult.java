package com.tutorialesvip.tutorialunittest.models;

public class SumarResult {

	private boolean isError = false;
	private String errorText;
	private Number result;
	
	public SumarResult(String error, Number result) {
		if (error != null) {
			this.isError = true;
			this.errorText = error;
		}
		else {
			this.result = result;
		}
	}
	
	
	@Override
	public String toString() {
		return "SumarResult [isError=" + isError + ", errorText=" + errorText + ", result=" + result + "]";
	}
	public boolean isError() {
		return isError;
	}
	public String getErrorText() {
		return errorText;
	}
	public Number getResult() {
		return result;
	}
	
	
			
}
