package com.tutorialesvip.tutorialunittest.util;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.tutorialesvip.tutorialunittest.businessException.ApplicationException;

class DiferenciaEntreFechasTest {

    @Autowired
    DiferenciaEntreFechas diferenciaEntreFechas;

    @Test
    void calculateYearsOfIndependency() throws ApplicationException {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = "27/02/1844";
        String tday = "28/03/1864";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate today = LocalDate.parse(tday, formatter);
        Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, today);

        Assertions.assertEquals(1,resultado.getMonths() );
        Assertions.assertEquals(1,resultado.getDays() );
        Assertions.assertEquals(20,resultado.getYears() );
    }
    
    @Test
    void calculateYearsOfIndependencyNullIndependenceDay() {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = null;
        String tday = "28/03/1864";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate today = LocalDate.parse(tday, formatter);

        Assertions.assertThrows(ApplicationException.class, () -> {
        	Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, today);
        });
    }
    @Test
    void calculateYearsOfIndependencyEmptyIndependenceDay() {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = "";
        String tday = "28/03/1864";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate today = LocalDate.parse(tday, formatter);
        

        Assertions.assertThrows(ApplicationException.class, () -> {
        	Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, today);
        });
    }
    @Test
    void calculateYearsOfIndependencyWrongFormatIndependenceDay() {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = "27-02-1844";
        String tday = "28/03/1864";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate today = LocalDate.parse(tday, formatter);
        

        Assertions.assertThrows(ApplicationException.class, () -> {
        	Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, today);
        });
    }
    
    @Test
    void calculateYearsOfIndependencyNullToday() {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = "27/02/1844";
        

        Assertions.assertThrows(ApplicationException.class, () -> {
        	Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, null);
        });
    }
    
    @Test
    void calculateYearsOfIndependencyPastReferenceDate() {
        diferenciaEntreFechas = new DiferenciaEntreFechas();
        String fechaIndependencia = "27/02/1844";
        String tday = "27/02/1824";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
        LocalDate today = LocalDate.parse(tday, formatter);
        

        Assertions.assertThrows(ApplicationException.class, () -> {
        	Period resultado = diferenciaEntreFechas.calculateYearsOfIndependency(fechaIndependencia, today);
        });
    }
    
}