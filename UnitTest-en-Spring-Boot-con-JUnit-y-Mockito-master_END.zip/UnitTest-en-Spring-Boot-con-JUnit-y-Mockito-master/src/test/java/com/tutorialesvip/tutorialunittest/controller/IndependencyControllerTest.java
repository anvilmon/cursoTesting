package com.tutorialesvip.tutorialunittest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.tutorialesvip.tutorialunittest.businessException.ApplicationException;
import com.tutorialesvip.tutorialunittest.models.Country;
import com.tutorialesvip.tutorialunittest.models.CountryResponse;
import com.tutorialesvip.tutorialunittest.repositories.CountryRepository;
import com.tutorialesvip.tutorialunittest.util.DiferenciaEntreFechas;

class IndependencyControllerTest {

    @Autowired
    CountryResponse countryResponse;
    @Autowired
    Optional<Country> country;

    CountryRepository countryRepositoryMock = Mockito.mock(CountryRepository.class);

    @Autowired
    DiferenciaEntreFechas diferenciaEntreFechas = new DiferenciaEntreFechas();

    @Autowired
    IndependencyController independencyController = new IndependencyController(countryRepositoryMock,diferenciaEntreFechas);

    @BeforeEach
    void setUp() {
        Country mockCountry = new Country();
        mockCountry.setIsoCode("DO");
        mockCountry.setCountryIdependenceDate("27/02/1844");
        mockCountry.setCountryId((long) 1);
        mockCountry.setCountryName("Republica Dominicana");
        mockCountry.setCountryCapital("Santo Domingo");

        Mockito.when(countryRepositoryMock.findCountryByIsoCode("DO")).thenReturn(mockCountry);

    }

    @Test
    void getCountryDetailsWithValidCountryCode() throws ApplicationException {
        ResponseEntity<CountryResponse> respuestaServicio;
        respuestaServicio = independencyController.getCountryDetails("DO");
        Assertions.assertEquals("Republica Dominicana",respuestaServicio.getBody().getCountryName());
    }

    @Test
    void getCountryDetailsWithInvalidCountryCode() throws ApplicationException {
        ResponseEntity<CountryResponse> respuestaServicio;
        respuestaServicio = independencyController.getCountryDetails("IT");
        Assertions.assertNull(respuestaServicio.getBody().getCountryName());
    }

    @Test
    void getAllCountriesTest() throws ApplicationException {
    	List<Country> lCountry = new ArrayList<>();
    	Country mockCountry = new Country();
        mockCountry.setIsoCode("DO");
        mockCountry.setCountryIdependenceDate("27/02/1844");
        mockCountry.setCountryId((long) 1);
        mockCountry.setCountryName("Republica Dominicana");
        mockCountry.setCountryCapital("Santo Domingo");
        lCountry.add(mockCountry);
        mockCountry = new Country();
        mockCountry.setIsoCode("ES");
        mockCountry.setCountryIdependenceDate("27/02/1864");
        mockCountry.setCountryId((long) 2);
        mockCountry.setCountryName("España");
        mockCountry.setCountryCapital("Madrid");
        lCountry.add(mockCountry);
        Mockito.when(countryRepositoryMock.findAll()).thenReturn(lCountry);
        ResponseEntity<List<CountryResponse>> resp = independencyController.getAllCountries();
        Assertions.assertEquals(resp.getBody().size(), 2);
        Assertions.assertEquals(resp.getBody().get(0).getCountryName(), "Republica Dominicana");
        Assertions.assertEquals(resp.getBody().get(1).getCountryName(), "España");
    }
    
    @Test
    void getAllCountriesTestNull() throws ApplicationException {
    	List<Country> lCountry = null;
        Mockito.when(countryRepositoryMock.findAll()).thenReturn(lCountry);
        ResponseEntity<List<CountryResponse>> resp = independencyController.getAllCountries();
        Assertions.assertEquals(resp.getBody().size(), 0);
    }
    
    @Test
    void getAllCountriesTestEmpty() throws ApplicationException {
    	List<Country> lCountry = new ArrayList<>();
        Mockito.when(countryRepositoryMock.findAll()).thenReturn(lCountry);
        ResponseEntity<List<CountryResponse>> resp = independencyController.getAllCountries();
        Assertions.assertEquals(resp.getBody().size(), 0);
    }
    
    @Test
    void getAllCountriesTestMocked() throws ApplicationException {
    	List<Country> lCountry = new ArrayList<>();
    	lCountry.add(mockCountry());
    	lCountry.add(mockCountry());
    	lCountry.add(mockCountry());
    	lCountry.add(mockCountry());
        Mockito.when(countryRepositoryMock.findAll()).thenReturn(lCountry);
        ResponseEntity<List<CountryResponse>> resp = independencyController.getAllCountries();
        Assertions.assertEquals(resp.getBody().size(), 4);
    }
    Country mockCountry ()  {
    	Country c = Mockito.mock(Country.class);
    	Mockito.when(c.getCountryIdependenceDate()).thenReturn("27/02/1864");
    	return c;
    }
    

}