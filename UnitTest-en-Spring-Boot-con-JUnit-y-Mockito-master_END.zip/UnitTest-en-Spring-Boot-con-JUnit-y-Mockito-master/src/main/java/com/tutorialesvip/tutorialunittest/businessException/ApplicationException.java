package com.tutorialesvip.tutorialunittest.businessException;

public class ApplicationException extends Exception{

}
